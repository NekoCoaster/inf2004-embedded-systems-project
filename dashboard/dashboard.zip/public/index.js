/**
* Purpose: Interact with MQTT service to receive real-time sensor readings and update HTML elements accordingly.
* Subscribes to specific MQTT topics for AS7341, FS3000, SCD41, MLX90614, NFA4X10 sensors.
* Updates corresponding HTML elements for each sensor and handles UI events for sliders and toggles.
* Dynamically updates chart appearance based on user interactions and initializes MQTT connection with appropriate callbacks.
*Creates a responsive web interface for visualizing and interacting with sensor data.
*/

// Import MQTT service
import { MQTTService } from "./mqttService.js";

// Target specific HTML items
const sideMenu = document.querySelector("aside");
const menuBtn = document.querySelector("#menu-btn");
const closeBtn = document.querySelector("#close-btn");
const themeToggler = document.querySelector(".theme-toggler");

let mqttService;
// Elements declared
// AS7341 : F1 , F2 , F3 , F4 , F5, F6, F7, F8, Visible, NIR
let F1 , F2 , F3 , F4 , F5, F6, F7, F8, Visible, NIR;
// FS3000 : RAW,  metersPerSec, milesPerHours
let RAW,  metersPerSec, milesPerHours;
// SCD41 : CO2, Temperature, Humidity
let CO2, Temperature, Humidity;
// MLX90614: ambientTemp, objectTemp
let ambientTemp, objectTemp;
// NFA4X10: RPM, DUTYCYCLE, DUTYCYCLE_OVERRIDE
let RPM, DUTYCYCLE, DUTYCYCLE_OVERRIDE;

// Elements to display sensor readings on the HTML page
// AS7341
let F1Element = document.getElementById("F1");
let F2Element = document.getElementById("F2");
let F3Element = document.getElementById("F3");
let F4Element = document.getElementById("F4");
let F5Element = document.getElementById("F5");
let F6Element = document.getElementById("F6");
let F7Element = document.getElementById("F7");
let F8Element = document.getElementById("F8");
let visibleElement = document.getElementById("Visible");
let NIRElement = document.getElementById("NIR");

// FS3000
let RAWElement = document.getElementById("RAW");
let metersPerSecElement = document.getElementById("metersPerSec");
let milesPerHoursElement = document.getElementById("milesPerHours");

// SCD41
let co2Element = document.getElementById("CO2");
let temperatureElement = document.getElementById("Temperature");
let humidityElement = document.getElementById("Humidity");

// MLX90614
let ambientTempElement = document.getElementById("ambientTemp");
let objectTempElement = document.getElementById("objectTemp");

// NFA4X10
let RPMElement = document.getElementById("RPM");
let DUTYCYCLEElement = document.getElementById("DUTYCYCLE");
let DUTYCYCLE_OVERRIDEElement = document.getElementById("DUTYCYCLE_OVERRIDE");


  // Add an event listener to track changes in the slider value
  // This toggle is to change the fan speed.
  const slider = document.getElementById("slider");
  const selectedValue = document.getElementById("selectedValue");

  slider.addEventListener("input", function() {
    selectedValue.textContent = slider.value;
    mqttService.publish("<GroupName>/PicoMqttUsername/DUTYCYCLE_OVERRIDE", selectedValue.textContent );
  });

  //Event listeners for toggle
  document.getElementById('toggle').addEventListener('change', function() {
    handleToggle(this,mqttService);

  });

// Holds the background color of all chart
var chartBGColor = getComputedStyle(document.body).getPropertyValue(
  "--chart-background"
);
var chartFontColor = getComputedStyle(document.body).getPropertyValue(
  "--chart-font-color"
);
var chartAxisColor = getComputedStyle(document.body).getPropertyValue(
  "--chart-axis-color"
);

/*
  Event listeners for any HTML click
*/
menuBtn.addEventListener("click", () => {
  sideMenu.style.display = "block";
});

closeBtn.addEventListener("click", () => {
  sideMenu.style.display = "none";
});

themeToggler.addEventListener("click", () => {
  document.body.classList.toggle("dark-theme-variables");
  themeToggler.querySelector("span:nth-child(1)").classList.toggle("active");
  themeToggler.querySelector("span:nth-child(2)").classList.toggle("active");

  // Update Chart background
  chartBGColor = getComputedStyle(document.body).getPropertyValue(
    "--chart-background"
  );
  chartFontColor = getComputedStyle(document.body).getPropertyValue(
    "--chart-font-color"
  );
  chartAxisColor = getComputedStyle(document.body).getPropertyValue(
    "--chart-axis-color"
  );
  updateChartsBackground();
});

/*
  Plotly.js graph and chart setup code
*/

//Getting element in HTML page
var temperatureHistoryDiv = document.getElementById("temperature-history");
var humidityHistoryDiv = document.getElementById("humidity-history");
var pressureHistoryDiv = document.getElementById("pressure-history");
var temperatureGaugeDiv = document.getElementById("temperature-gauge");
var humidityGaugeDiv = document.getElementById("humidity-gauge");
var pressureGaugeDiv = document.getElementById("pressure-gauge");

const historyCharts = [
  temperatureHistoryDiv,
  humidityHistoryDiv,
  pressureHistoryDiv,
];

const gaugeCharts = [
  temperatureGaugeDiv,
  humidityGaugeDiv,
  pressureGaugeDiv,
];

// History Data
var temperatureTrace = {
  x: [],
  y: [],
  name: "Temperature",
  mode: "lines+markers",
  type: "line",
};
var humidityTrace = {
  x: [],
  y: [],
  name: "Humidity",
  mode: "lines+markers",
  type: "line",
};
var pressureTrace = {
  x: [],
  y: [],
  name: "Pressure",
  mode: "lines+markers",
  type: "line",
};

var temperatureLayout = {
  autosize: true,
  title: {
    text: "Temperature",
  },
  font: {
    size: 12,
    color: chartFontColor,
    family: "poppins, san-serif",
  },
  colorway: ["#05AD86"],
  margin: { t: 40, b: 40, l: 30, r: 30, pad: 10 },
  plot_bgcolor: chartBGColor,
  paper_bgcolor: chartBGColor,
  xaxis: {
    color: chartAxisColor,
    linecolor: chartAxisColor,
    gridwidth: "2",
    autorange: true,
  },
  yaxis: {
    color: chartAxisColor,
    linecolor: chartAxisColor,
    gridwidth: "2",
    autorange: true,
  },
};
var humidityLayout = {
  autosize: true,
  title: {
    text: "Humidity",
  },
  font: {
    size: 12,
    color: chartFontColor,
    family: "poppins, san-serif",
  },
  colorway: ["#05AD86"],
  margin: { t: 40, b: 40, l: 30, r: 30, pad: 0 },
  plot_bgcolor: chartBGColor,
  paper_bgcolor: chartBGColor,
  xaxis: {
    color: chartAxisColor,
    linecolor: chartAxisColor,
    gridwidth: "2",
  },
  yaxis: {
    color: chartAxisColor,
    linecolor: chartAxisColor,
  },
};

var config = { responsive: true, displayModeBar: false };

// Event listener when page is loaded
window.addEventListener("load", (event) => {
  Plotly.newPlot(
    temperatureHistoryDiv,
    [temperatureTrace],
    temperatureLayout,
    config
  );
  Plotly.newPlot(humidityHistoryDiv, [humidityTrace], humidityLayout, config);

  // Get MQTT Connection
  fetchMQTTConnection();
  // Run it initially
  handleDeviceChange(mediaQuery);
});

// Gauge Data
var temperatureData = [
  {
    domain: { x: [0, 1], y: [0, 1] },
    value: 0,
    title: { text: "Temperature" },
    type: "indicator",
    mode: "gauge+number+delta",
    delta: { reference: 30 },
    gauge: {
      axis: { range: [null, 50] },
      steps: [
        { range: [0, 20], color: "lightgray" },
        { range: [20, 30], color: "gray" },
      ],
      threshold: {
        line: { color: "red", width: 4 },
        thickness: 0.75,
        value: 30,
      },
    },
  },
];

var humidityData = [
  {
    domain: { x: [0, 1], y: [0, 1] },
    value: 0,
    title: { text: "Humidity" },
    type: "indicator",
    mode: "gauge+number+delta",
    delta: { reference: 50 },
    gauge: {
      axis: { range: [null, 100] },
      steps: [
        { range: [0, 20], color: "lightgray" },
        { range: [20, 30], color: "gray" },
      ],
      threshold: {
        line: { color: "red", width: 4 },
        thickness: 0.75,
        value: 30,
      },
    },
  },
];

var pressureData = [
  {
    domain: { x: [0, 1], y: [0, 1] },
    value: 0,
    title: { text: "CO2" },
    type: "indicator",
    mode: "gauge+number+delta",
    delta: { reference: 750 },
    gauge: {
      axis: { range: [null, 1100] },
      steps: [
        { range: [0, 300], color: "lightgray" },
        { range: [300, 700], color: "gray" },
      ],
      threshold: {
        line: { color: "red", width: 4 },
        thickness: 0.75,
        value: 30,
      },
    },
  },
];
var layout = { width: 300, height: 250, margin: { t: 0, b: 0, l: 0, r: 0 } };

Plotly.newPlot(temperatureGaugeDiv, temperatureData, layout);
Plotly.newPlot(humidityGaugeDiv, humidityData, layout);
Plotly.newPlot(pressureGaugeDiv, pressureData, layout);

// Will hold the arrays we receive from our BME280 sensor
// Temperature
let newTempXArray = [];
let newTempYArray = [];
// Humidity
let newHumidityXArray = [];
let newHumidityYArray = [];
// Pressure
let newPressureXArray = [];
let newPressureYArray = [];
// Altitude
let newAltitudeXArray = [];
let newAltitudeYArray = [];

// The maximum number of data points displayed on our scatter/line graph
let MAX_GRAPH_POINTS = 12;
let ctr = 0;

// Callback function that will retrieve our latest sensor readings and redraw our Gauge with the latest readings
function updateSensorReadingsSCD41(jsonResponse) {
  console.log(typeof jsonResponse);
  console.log(jsonResponse);

  let temperature = Number(jsonResponse.Temperature).toFixed(2);
  let humidity = Number(jsonResponse.Humidity).toFixed(2);
  let CO2 = Number(jsonResponse.CO2).toFixed(2);
  updateBox(temperatureElement, temperature);
  updateBox(humidityElement, humidity);
  updateBox(co2Element, CO2);
  updateGauge(temperature, humidity,CO2);
  //Update Temperature Line Chart
  updateCharts(
    temperatureHistoryDiv,
    newTempXArray,
    newTempYArray,
    temperature
  );
}

// This function get the jsonResponse AS7341 data from MQTT update the respective boxes chart in the HTML page
// The boxes are updated at real-time
function updateSensorReadingsAS7341(jsonResponse) {
  console.log("Updating AS7341 sensor readings:", jsonResponse);
  let F1 = Number(jsonResponse.F1).toFixed(2);
  let F2 = Number(jsonResponse.F2).toFixed(2);
  let F3 = Number(jsonResponse.F3).toFixed(2);
  let F4 = Number(jsonResponse.F4).toFixed(2);
  let F5 = Number(jsonResponse.F5).toFixed(2);
  let F6 = Number(jsonResponse.F6).toFixed(2);
  let F7 = Number(jsonResponse.F7).toFixed(2);
  let F8 = Number(jsonResponse.F8).toFixed(2);
  let Visible = Number(jsonResponse.Visible).toFixed(2);
  let NIR = Number(jsonResponse.NIR).toFixed(2);



  updateBox(F1Element,F1);
  updateBox(F2Element,F2);
  updateBox(F3Element,F3);
  updateBox(F4Element,F4);
  updateBox(F5Element,F5);
  updateBox(F6Element,F6);
  updateBox(F7Element,F7);
  updateBox(F8Element,F8);
  updateBox(visibleElement,Visible);
  updateBox(NIRElement,NIR);

  updateChartsSpectrum(
    humidityHistoryDiv,
    [],
    [],
    [F1,F2,F3,F4,F5,F6,F7,F8]
  );

}

// This function get the jsonResponse FS3000 data from MQTT update the respective boxes in the HTML page
// The boxes are updated at real-time
function updateSensorReadingsFS3000(jsonResponse) {
  // Add your logic to update FS3000 sensor readings here
  console.log("Updating FS3000 sensor readings:", jsonResponse);
  let RAW = Number(jsonResponse.RAW).toFixed(2);
  let metersPerSec = Number(jsonResponse.metersPerSec).toFixed(2);
  let milesPerHour = Number(jsonResponse.milesPerHour).toFixed(2);
  updateBox(RAWElement,RAW);
  updateBox(metersPerSecElement,metersPerSec);
  updateBox(milesPerHoursElement,milesPerHour);
}

// This function get the jsonResponse MLX90614 data from MQTT update the respective boxes in the HTML page
// The boxes are updated at real-time
function updateSensorReadingsMLX90614(jsonResponse) {

  console.log("Updating MLX90614 sensor readings:", jsonResponse);
  let ambientTemp = Number(jsonResponse.ambientTemp).toFixed(2);
  let objectTemp = Number(jsonResponse.objectTemp).toFixed(2);

  updateBox(ambientTempElement,ambientTemp);
  updateBox(objectTempElement,objectTemp);
}

// This function get the jsonResponse NFA4X10 data from MQTT update the respective boxes in the HTML page
// The boxes are updated at real-time
function updateSensorReadingsNFA4X10(jsonResponse) {
  // Add your logic to update NFA4X10 sensor readings here
  console.log("Updating NFA4X10 sensor readings:", jsonResponse);
  let RPM = Number(jsonResponse.RPM).toFixed(2);
  let DUTYCYCLE = Number(jsonResponse.DUTYCYCLE).toFixed(2);
  let DUTYCYCLE_OVERRIDE = Number(jsonResponse.DUTYCYCLE_OVERRIDE).toFixed(2);

  updateBox(RPMElement,RPM);
  updateBox(DUTYCYCLEElement,DUTYCYCLE);
  updateBox(DUTYCYCLE_OVERRIDEElement,DUTYCYCLE_OVERRIDE);
  
  
}

//This function check for any value passed by jsonResponse is "NaN".
function updateBox(boxId, value) {
  // Get the corresponding box element

  // Update the box only if the value is not null
  if (value !== "NaN") {
    boxId.innerHTML = value;
  }
}

/**
 * Updates gauge charts with new temperature, humidity, and pressure values.
 *  temperature - The new temperature value.
 * humidity - The new humidity value.
 *  pressure - The new CO2 value.
 */
function updateGauge(temperature, humidity, pressure) {
  var temperature_update = {
    value: temperature,
  };
  var humidity_update = {
    value: humidity,
  };
  var pressure_update = {
    value: pressure,
  };

  Plotly.update(temperatureGaugeDiv, temperature_update);
  Plotly.update(humidityGaugeDiv, humidity_update);
  Plotly.update(pressureGaugeDiv, pressure_update);

}

/**
 * Update the line chart with new data points.
 *
 *  lineChartDiv - The ID or reference to the div containing the line chart.
 *  xArray - Array containing x-axis data points.
 *  yArray - Array containing y-axis data points.
 *  sensorRead - The latest sensor reading  to be added to the chart.
 *  MAX_GRAPH_POINTS is set to 8
 *  Plotly is used to plot the graph
 */
function updateCharts(lineChartDiv, xArray, yArray, sensorRead) {
   // Ensure that the number of data points does not exceed the maximum specified limit.
  if (xArray.length >= MAX_GRAPH_POINTS) {
    // Remove the oldest x-axis data point.
    xArray.shift(); 
  }
  if (yArray.length >= MAX_GRAPH_POINTS) {
    // Remove the oldest y-axis data point.
    yArray.shift();
  }
   // Add the new data point to the arrays.
  xArray.push(ctr++);
  yArray.push(sensorRead);

  // Prepare the updated data structure for Plotly.
  var data_update = {
    x: [xArray],
    y: [yArray],
  };

  // Use Plotly to update the chart with the new data.
  Plotly.update(lineChartDiv, data_update);
}

/**
 * Update the line chart with spectrum data.
 *
 *  lineChartDiv - The ID or reference to the div containing the line chart.
 *  xArray - Array containing x-axis data points.
 *  yArray - Array containing y-axis data points.
 *  sensorRead - Array of sensor readings representing spectrum data.
 */
function updateChartsSpectrum(lineChartDiv, xArray, yArray, sensorRead) {
  // Reset xArray and yArray to empty arrays to clear existing data.
  xArray = [];
  yArray = [];

  // Add new data points from the sensorRead array to xArray and yArray
  for (let i = 0; i < sensorRead.length; i++) {
    xArray.push(ctr++);
    yArray.push(sensorRead[i]);
  }

  // Create an object with updated x and y arrays
  var data_update = {
    x: [xArray],
    y: [yArray],
  };
  // Use Plotly to update the chart with the new spectrum data.
  Plotly.update(lineChartDiv, data_update);
}

function updateChartsBackground() {
  // updates the background color of historical charts
  var updateHistory = {
    plot_bgcolor: chartBGColor,
    paper_bgcolor: chartBGColor,
    font: {
      color: chartFontColor,
    },
    xaxis: {
      color: chartAxisColor,
      linecolor: chartAxisColor,
    },
    yaxis: {
      color: chartAxisColor,
      linecolor: chartAxisColor,
    },
  };
  historyCharts.forEach((chart) => Plotly.relayout(chart, updateHistory));

  // updates the background color of gauge charts
  var gaugeHistory = {
    plot_bgcolor: chartBGColor,
    paper_bgcolor: chartBGColor,
    font: {
      color: chartFontColor,
    },
    xaxis: {
      color: chartAxisColor,
      linecolor: chartAxisColor,
    },
    yaxis: {
      color: chartAxisColor,
      linecolor: chartAxisColor,
    },
  };
  gaugeCharts.forEach((chart) => Plotly.relayout(chart, gaugeHistory));
}

const mediaQuery = window.matchMedia("(max-width: 600px)");

mediaQuery.addEventListener("change", function (e) {
  handleDeviceChange(e);
});

function handleDeviceChange(e) {
  if (e.matches) {
    console.log("Inside Mobile");
    var updateHistory = {
      width: 323,
      height: 250,
      "xaxis.autorange": true,
      "yaxis.autorange": true,
    };
    historyCharts.forEach((chart) => Plotly.relayout(chart, updateHistory));
  } else {
    var updateHistory = {
      width: 550,
      height: 260,
      "xaxis.autorange": true,
      "yaxis.autorange": true,
    };
    historyCharts.forEach((chart) => Plotly.relayout(chart, updateHistory));
  }
}

const mqttStatus = document.querySelector(".status");

/**
 * Updates the UI status element when MQTT connection is established.
 *  message - The message received on successful connection.
 */
function onConnect(message) {
  mqttStatus.textContent = "Connected";
}

/**
 *  Handles incoming MQTT messages and updates sensor readings based on the topic.
 *  topic - The MQTT topic associated with the incoming message.
 *  message - The MQTT message received.
 */
function onMessage(topic, message) {
  var stringResponse = message.toString();
  var messageResponse = JSON.parse(stringResponse);
  if (topic === "<GroupName>/PicoMqttUsername/AS7341") {
    updateSensorReadingsAS7341(messageResponse);
  } else if (topic === "<GroupName>/PicoMqttUsername/FS3000") {
    updateSensorReadingsFS3000(messageResponse);
  } else if (topic === "<GroupName>/PicoMqttUsername/SCD41") {
    updateSensorReadingsSCD41(messageResponse);
  } else if (topic === "<GroupName>/PicoMqttUsername/MLX90614") {
    updateSensorReadingsMLX90614(messageResponse);
  } else if (topic === "<GroupName>/PicoMqttUsername/NFA4X10") {
    updateSensorReadingsNFA4X10(messageResponse);
  }
}

/**
 * Handles errors encountered during MQTT communication.
 * error - The error message or description.
 */
function onError(error) {
  console.log(`Error encountered :: ${error}`);
  mqttStatus.textContent = "Error";
}

/**
 * Handles the event when the MQTT connection is closed.
 */
function onClose() {
  console.log(`MQTT connection closed!`);
  mqttStatus.textContent = "Closed";
}

/**
 * Fetches MQTT connection details from the server.
 * Initiates the MQTT connection with the obtained details.
 */
function fetchMQTTConnection() {
  fetch("/mqttConnDetails", {
    method: "GET",
    headers: {
      "Content-type": "application/json; charset=UTF-8",
    },
  })
    .then(function (response) {
      return response.json();
    })
    .then(function (data) {
      initializeMQTTConnection(data.mqttServer, data.mqttTopic);
    })
    .catch((error) => console.error("Error getting MQTT Connection :", error));
}

/**
 *  Initializes the MQTT connection with the specified server and topic.
 *  mqttServer - The MQTT server address.
 *  mqttTopic - The MQTT topic to subscribe to.
 */
function initializeMQTTConnection(mqttServer, mqttTopic) {
  console.log(
    `Initializing connection to :: ${mqttServer}, topic :: ${mqttTopic}`
  );
  var fnCallbacks = { onConnect, onMessage, onError, onClose };

  mqttService = new MQTTService(mqttServer, fnCallbacks);
  mqttService.connect();


  mqttService.subscribe("<GroupName>/PicoMqttUsername/SCD41");
  mqttService.subscribe("<GroupName>/PicoMqttUsername/NFA4X10");
  mqttService.subscribe("<GroupName>/PicoMqttUsername/MLX90614");
  mqttService.subscribe("<GroupName>/PicoMqttUsername/AS7341");
  mqttService.subscribe("<GroupName>/PicoMqttUsername/FS3000");
  
}

/**
 * Handles the toggle event for a checkbox, publishing MQTT messages accordingly.
 *  checkbox - The checkbox element.
 *  The MQTT service object.
 */
function handleToggle(checkbox, mqttService) {
  // Get the value of the checkbox (true if checked, false if unchecked)
  const isChecked = checkbox.checked;

  // Pass the value to index.js or perform any action
  if (isChecked) {
    // Value when toggle is ON
    mqttService.publish("<GroupName>/PicoMqttUsername/lightStatus", "ON");
   
  } else {
    // Value when toggle is OFF
    mqttService.publish("<GroupName>/PicoMqttUsername/lightStatus", "OFF");

  }
}
